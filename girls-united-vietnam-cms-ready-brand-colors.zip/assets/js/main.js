// Girls United Vietnam: navigation, footer year and editable CMS content.
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const isOpen = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!isOpen));
      nav.classList.toggle("is-open", !isOpen);
      toggle.setAttribute("aria-label", isOpen ? "Open navigation" : "Close navigation");
    });
    nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Open navigation");
    }));
  }
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());

  const safeText = value => String(value ?? "");
  const setText = (id, value) => {
    const el = document.getElementById(id);
    if (el && value) el.textContent = value;
  };
  const setRichHeading = (id, value) => {
    const el = document.getElementById(id);
    if (!el || !value) return;
    const words = safeText(value).split(" ");
    el.textContent = "";
    const first = words.slice(0, -1).join(" ");
    if (first) el.append(document.createTextNode(first + " "));
    const em = document.createElement("em");
    em.textContent = words.length > 1 ? words[words.length - 1] : value;
    el.append(em);
  };
  const loadJson = async path => {
    try {
      const response = await fetch(path);
      if (!response.ok) throw new Error("Content unavailable");
      return await response.json();
    } catch (error) {
      console.warn("Girls United Vietnam content could not be loaded:", path, error);
      return null;
    }
  };

  const page = location.pathname.split("/").pop() || "index.html";
  if (page === "index.html") {
    loadJson("content/home.json").then(data => {
      if (!data) return;
      setText("cms-home-eyebrow", data.home_eyebrow);
      setText("cms-home-heading", data.home_heading);
      setText("cms-home-intro", data.home_intro);
      setText("cms-home-about-heading", data.home_about_heading);
      setText("cms-home-about-text", data.home_about_text);
      setText("cms-home-about-detail", data.home_about_detail);
    });
  }

  if (page === "about.html") {
    loadJson("content/about.json").then(data => {
      if (!data) return;
      setText("cms-about-heading", data.mission_heading);
      setText("cms-about-intro", data.mission_intro);
      setText("cms-about-detail", data.mission_detail);
    });
  }

  if (page === "events.html") {
    loadJson("content/events.json").then(events => {
      const container = document.getElementById("cms-events-list");
      if (!container || !Array.isArray(events)) return;
      container.replaceChildren();
      events.forEach(event => {
        const article = document.createElement("article");
        article.className = "event-listing";
        const image = document.createElement("div");
        image.className = "event-list-image";
        if (event.image) {
          image.style.backgroundImage = `url("${event.image}")`;
          image.style.backgroundSize = "cover";
          image.style.backgroundPosition = "center";
        } else {
          image.classList.add("event-art");
        }
        const content = document.createElement("div");
        content.className = "event-list-content";
        const status = document.createElement("span");
        status.className = "event-status";
        status.textContent = event.status || "Upcoming";
        const category = document.createElement("p");
        category.className = "eyebrow";
        category.textContent = event.category || "";
        const title = document.createElement("h3");
        title.textContent = event.title || "";
        const description = document.createElement("p");
        description.textContent = event.description || "";
        const details = document.createElement("span");
        details.className = "event-detail";
        details.textContent = event.details || "";
        content.append(status, category, title, description, details);
        article.append(image, content);
        container.append(article);
      });
    });
  }

  if (page === "initiatives.html") {
    loadJson("content/initiatives.json").then(items => {
      const container = document.getElementById("cms-initiatives-list");
      if (!container || !Array.isArray(items)) return;
      container.replaceChildren();
      items.forEach((item, index) => {
        const article = document.createElement("article");
        article.className = "initiative-row" + (index % 2 ? " reverse" : "");
        article.id = item.slug || `initiative-${index + 1}`;
        const photo = document.createElement("div");
        photo.className = "initiative-photo " + ["photo-health","photo-sport","photo-creative","photo-community"][index % 4];
        const number = document.createElement("span");
        number.textContent = item.number || String(index + 1).padStart(2, "0");
        photo.append(number);
        const content = document.createElement("div");
        content.className = "initiative-content";
        const eyebrow = document.createElement("p");
        eyebrow.className = "eyebrow";
        eyebrow.textContent = item.eyebrow || "";
        const title = document.createElement("h2");
        title.textContent = item.title || "";
        const description = document.createElement("p");
        description.textContent = item.description || "";
        const list = document.createElement("ul");
        (item.points || []).forEach(point => {
          const li = document.createElement("li");
          li.textContent = point;
          list.append(li);
        });
        content.append(eyebrow, title, description, list);
        article.append(photo, content);
        container.append(article);
      });
    });
  }

  const form = document.getElementById("interest-form");
  const notice = document.getElementById("form-notice");
  if (form && notice) form.addEventListener("submit", event => {
    event.preventDefault();
    notice.textContent = "Thanks for your interest! This is currently a design preview. Connect a form service before accepting real submissions.";
    notice.classList.add("notice-highlight");
  });
});
